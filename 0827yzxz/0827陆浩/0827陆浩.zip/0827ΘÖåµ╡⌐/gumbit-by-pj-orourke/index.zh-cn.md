---
title: "Gumbit by PJ ORourke"
description: "嚼口香糖。追逐你的梦想。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gumbit-by-pj-orourke.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.gumbit.xyz/"
twitter: ""
discord: "https://discord.gg/gumbit"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/gumbitnft"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ PJ ORourke 的 Gumbit 是什么？
PJ ORourke 的 Gumbit 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。
▶ 有多少 Gumbit by PJ ORourke 代币？
PJ ORourke NFT 总共有 1,232 个 Gumbit。目前，115 位所有者的钱包中至少有一个 PJ ORourke NTF 的 Gumbit。
▶ PJ ORourke 出售的最贵的 Gumbit 是什么？
PJ ORourke NFT 出售的最昂贵的 Gumbit 是 Gumbit #206。它于 2022-07-01（大约 2 个月前）以 243.7 美元的价格售出。
▶ PJ ORourke 的 Gumbit 最近卖出了多少？
在过去 30 天内，PJ ORourke NFT 售出 1 个 Gumbit。

![nft](1661595434882(1).png)