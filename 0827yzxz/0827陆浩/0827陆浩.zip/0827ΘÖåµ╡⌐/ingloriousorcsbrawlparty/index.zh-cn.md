---
title: "IngloriousOrcsBrawlParty"
description: "不光彩的兽人，一个被遗忘的古老部落的后裔已经准备好隆隆作响"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "ingloriousorcsbrawlparty.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://ingloriousorcsbrawlparty.io/"
twitter: "https://www.twitter.com/IngloriousOrcs"
discord: "https://discord.gg/75cTQ4BW2p"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是 IngloriousOrcsBrawlParty？
IngloriousOrcsBrawlParty 是一个 NFT（不可替代令牌）集合。 存储在区块链上的数字艺术品集合。
▶ 存在多少 IngloriousOrcsBrawlParty 代币？
总共有 2,055 个 IngloriousOrcsBrawlParty NFT。 目前，403 位所有者的钱包中至少有一个 IngloriousOrcsBrawlParty NTF。
▶ 最近卖出了多少个 IngloriousOrcsBrawlParty？
过去 30 天内售出了 1 个 IngloriousOrcsBrawlParty NFT。
  交互式 NFT p不光彩的兽人，一个被遗忘的古老部落的后裔，已经准备好隆隆声了。
一个 100% 手绘集合，非常详细，包含 500 多个特征。
在 4 个部落中做出选择。



![nft](1661598588802(1).png)