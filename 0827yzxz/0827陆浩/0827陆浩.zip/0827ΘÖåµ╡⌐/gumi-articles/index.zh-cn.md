---
title: "gumi articles"
description: "来自gumi的书架式阅读材料集合"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gumi-articles.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://bangumi.gu3.co.jp/"
twitter: "https://twitter.com/GUMIGlasgow"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是gumi篇？
gumi 文章是一个 NFT（非同质化代币）集合。存储在区块链上的数字艺术品集合。
▶ 有多少个gumi文章代币？
总共有 1 篇 gumi 文章 NFT。目前有 1 位所有者的钱包中至少有一篇 gumi 文章 NTF。
▶ 什么是最昂贵的gumi商品销售？
卖得最贵的古米文章 NFT 是 古米在区块链领域的第一个自有媒体 NFT。它于 2022-06-10（3 个月前）以 5.3 美元的价格售出。
▶ 最近卖了多少gumi文章？
过去 30 天内售出 1 条 gumi 文章 NFT。

![nft](1661595654456(1).png)
