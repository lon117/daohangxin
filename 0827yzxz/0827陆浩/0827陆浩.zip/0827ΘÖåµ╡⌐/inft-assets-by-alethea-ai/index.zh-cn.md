---
title: "iNFT Assets by Alethea AI"
description: "Alethea AI 正在构建一个去中心化的 iNFT 协议"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "inft-assets-by-alethea-ai.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://alethea.ai/"
twitter: "https://www.twitter.com/real_alethea"
discord: "https://discord.gg/aletheaai"
telegram: "https://t.me/alethea_ai"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://www.medium.com/@/alethea-ai"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Alethea AI 正在构建一个去中心化的 iNFT 协议，以创建一个由交互式和智能 NFT 居住的智能元宇宙。 iNFT 资产不仅使 iNFT 能够增强其能力，而且还拥有和发展其身份的关键方面。▶ 什么是 Alethea AI 的 iNFT 资产？
Alethea AI 的 iNFT Assets 是一个 NFT（不可替代代币）集合。 存储在区块链上的数字艺术品集合。
▶ Alethea AI 代币的 iNFT 资产有多少？
Alethea AI NFT 总共有 2,143 个 iNFT 资产。 目前，660 位所有者的钱包中至少有一个 Alethea AI NTF 的 iNFT 资产。
▶ Alethea AI 出售的最昂贵的 iNFT 资产是什么？
Alethea AI NFT 出售的最昂贵的 iNFT 资产是 ARKIV。 它于 2022 年 6 月 4 日（3 个月前）以 200.1 美元的价格售出。
▶ Alethea AI 最近卖出了多少 iNFT 资产？
在过去 30 天内，Alethea AI NFT 出售了 26 个 iNFT 资产。
▶ Alethea AI 的 iNFT 资产需要多少钱？
在过去 30 天里，Alethea AI NFT 最便宜的 iNFT 资产销售额低于 79 美元，最高销售额超过 200 美元。 Alethea AI NFT 的 iNFT 资产在过去 30 天内的中位价格为 97 美元。

![nft](1661598266348(1).png)