---
title: "GUNBULL NFT"
description: "Gunbull 是一个有限的 NFT。每个代币都带有一个独特的配对实体玩具"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gunbull-v2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/gunbull-v2"
twitter: "https://www.twitter.com/GunbullNFT"
discord: "https://discord.gg/gunbull"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
##### ▶ 什么是 GUNBULL NFT？GUNBULL NFT 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。▶ GUNBULL NFT 代币有多少？总共有 204 个 GUNBULL NFT NFT。目前，121 位所有者的钱包中至少有一个 GUNBULL NFT NTF。▶ 最近卖出了多少 GUNBULL NFT？过去 30 天内售出 0 个 GUNBULL NFT NFT。Gunbull 是一个有限的 NFT。每个代币都带有一个独特的配对实体玩具。▶ GUNBULL NFT 代币有多少？

总共有 204 个 GUNBULL NFT NFT。目前，121 位所有者的钱包中至少有一个 GUNBULL NFT NTF。

![nft](1661596032491(1).png)