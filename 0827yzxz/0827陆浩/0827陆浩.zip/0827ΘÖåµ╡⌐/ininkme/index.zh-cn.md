---
title: "Ininkme"
description: "Ininkme 将允许任何合适的 DeGame/DeSocial 平台导入我们的原创角色。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "ininkme.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://inink.ink/"
twitter: "https://www.twitter.com/ininkme"
discord: "https://discord.gg/uQ9NhtWnR2"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是 Ininkme？
Ininkme 是一个 NFT（不可替代代币）集合。 存储在区块链上的数字艺术品集合。
▶ 有多少 Ininkme 代币？
总共有 187 个 Ininkme NFT。 目前，112 位所有者的钱包中至少有一个 Ininkme NTF。
▶ 最昂贵的 Ininkme 销售是什么？
最昂贵的 Ininkme NFT 是恋人·女·。 它于 2022 年 6 月 9 日（3 个月前）以 100.1 美元的价格售出。
▶ 最近卖出了多少 Ininkme？
过去 30 天内售出了 27 个 Ininkme NFT。
▶ Ininkme 的价格是多少？
在过去 30 天里，Ininkme NFT 最便宜的销售额低于 18 美元，最高销售额超过 91 美元。 Ininkme NFT 在过去 30 天内的中位价格为 63 美元。
▶ 什么是流行的 Ininkme 替代品？
许多拥有 Ininkme NFT 的用户还拥有 Old Legacy、WaterBe4nZuki、DegenOkayBears 和 DoNotMintThis。

![nft](1661598958245(1).png)