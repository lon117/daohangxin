---
title: "Guilded Gods V2"
description: "6,666 位公会众神升入以太坊区块链，准备一次一个 NFT 保护奥林巴斯的公民。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "guilded-gods-v2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://guildedgods.io/"
twitter: "https://twitter.com/guildsofgods"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么是公会众神 V2？Guilded Gods V2 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。 Guilded Gods V2 代币有多少？总共有 5,910 个 Guilded Gods V2 NFT。目前，1,246 位所有者的钱包中至少有一个 Guilded Gods V2 NTF。 公会神V2最近卖出了多少？
过去 30 天内售出 0 个 Guilded Gods V2 NFT。6,666 位公会众神升入以太坊区块链，准备一次一个 NFT 保护奥林巴斯的公民。 通过铸造您的 Guilded Gods NFT 来追求荣耀和您在宝座上的位置。 奥林巴斯张开双臂欢迎您！

![1661594865308(1)](1661594865308(1).png)