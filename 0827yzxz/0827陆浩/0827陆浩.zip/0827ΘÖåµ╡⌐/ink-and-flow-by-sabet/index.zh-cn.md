---
title: "INK AND FLOW BY S@BET"
description: "1 of 1 画作的集合"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "ink-and-flow-by-sabet.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://www.sabet.art/"
twitter: "https://www.twitter.com/sabet"
discord: "https://discord.gg/sabet"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/sabet"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
1 幅画作中的一幅，采用传统印度墨水和 Ali Sabet 的特殊统治笔手工创作。 每件作品都是近乎即时的创作。 静止中的动态画。

▶ 什么是 INK AND FLOW BY S@BET？
S@BET 的 INK AND FLOW 是一个 NFT（不可替代代币）集合。 存储在区块链上的数字艺术品集合。
▶ 存在多少 INK AND FLOW BY S@BET 代币？
S@BET NFT 总共有 28 个 INK AND FLOW。 目前，22 位所有者的钱包中至少有一份 INK AND FLOW BY S@BET NTF。
▶ INK AND FLOW BY S@BET 最近卖出了多少？
在过去 30 天内售出 0 个 INK AND FLOW BY S@BET NFT。

![nft](1661599365780(1).png)