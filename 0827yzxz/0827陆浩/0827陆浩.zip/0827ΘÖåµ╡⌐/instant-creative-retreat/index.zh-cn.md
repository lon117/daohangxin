---
title: "Instant Creative Retreat"
description: "从你的耳朵之间收集创世纪。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "instant-creative-retreat.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://betweenyourears.xyz/"
twitter: "https://www.twitter.com/AlexGWeiser"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
从你的耳朵之间收集创世纪。 一个基于正念的项目和配对游戏，可在您的脑海中打开空间。88 张即时照片和 88 个以这些照片为特色的冥想视频。 2022 年初的一系列半定期下降。收集照片/视频对以获得实物 1/1 即时照片 + 其他具有创造性的刺激奖励。 获得 IRL 创意静修、基于正念的空投和深度思考者社区。即时照片非常罕见。这是帮助他人更有创意地流动的终生使命的开始。

![nft](1661600268610(1).png)