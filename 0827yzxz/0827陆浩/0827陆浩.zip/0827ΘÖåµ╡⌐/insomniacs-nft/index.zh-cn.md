---
title: "Insomniacs NFT"
description: "6666 手绘恶作剧，灵感来自失眠。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "insomniacs-nft.jpg"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/insomniacs-nft"
twitter: "https://www.twitter.com/InsomniacsNFT"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
6666 手绘恶作剧，灵感来自失眠。 在阴暗的小巷里。 空荡荡的房子里。 在若隐若现的树木之中。 在旧阁楼上。 在被遗忘的地下室。 谁知道在黑暗中爬行的是什么？ 只有合同和推特。 1 是免费的，然后每个 0.0066。 每个钱包最多 6 个。▶ 什么是失眠官员？
Insomniac Official 是一个 NFT（非同质代币）集合。 存储在区块链上的数字艺术品集合。
▶ Insomniac 官方代币有多少？
总共有 75,046 个 Insomniac 官方 NFT。 目前，16,165 位车主的钱包中至少有一个 Insomniac Official NTF。
▶ 最近卖出了多少 Insomniac Official？
过去 30 天内共售出 0 个 Insomniac 官方 NFT。

![nft](1661599987333(1).png)