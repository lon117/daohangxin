---
title: "Infinite Tiles"
description: "人类的特点是渴望围绕思想形成社区"
ddate: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "infinite-tiles.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/infinite-tiles"
twitter: "https://www.twitter.com/Tile_DAO"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
人类的特点是渴望围绕满足我们对美的重叠解释的想法、符号和人工制品形成社区。 Tiles 是对赋予这些社区意义的东西的庆祝：个人。每个可能的 ETH 钱包地址都会生成一个 Tile——每个地址都代表去中心化生态系统中的唯一身份，使这样的项目成为可能。从数学上讲，所有 Tiles 都同样罕见 . 它们都是由相同种类的简单形状和颜色制成的，但每种都以独特的方式。 从这个意义上说，Tiles 有点像我们。拥有一个 Tile 是一个参与 TileDAO 的邀请，TileDAO 将获得 Tiles 主要销售的所有收入。 由于供应几乎是无限的，只要 Tiles 被售出，DAO 的资金可能会无限期地持续下去。



![nft](1661597567793(1).png)