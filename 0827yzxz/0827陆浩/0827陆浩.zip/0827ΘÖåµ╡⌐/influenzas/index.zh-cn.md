---
title: "INFLUENZAS"
description: "由 250 个 NFT“影响者”的被盗推文数据制成的生成艺术品"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "influenzas.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://influenzas.wtf/"
twitter: "https://www.twitter.com/rug_tech"
discord: "https://discord.gg/qnft"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
由 250 个 NFT“影响者”的被盗推文数据制成的生成艺术品来自地球上的垃圾或 NFT 夏天的深刻漫谈的星际传输......你是法官。> 推文作者通过智能合约自动收到 100% 的薄荷收益 .> RUG.TECH 收取 100% 的二次利润（每次销售 10%）。> 生成算法是 FUCKINGRUG 的第一个 NFT 项目的一个分支。 如果您想找到最好的 NFT 购买、即将推出的 NFT 项目、最昂贵的 NFT 是什么——我们将为您提供您需要的数据、图表、见解和新闻。

![nft](1661598074645(1).png)

