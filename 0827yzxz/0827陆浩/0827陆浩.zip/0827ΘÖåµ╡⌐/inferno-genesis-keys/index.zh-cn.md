---
title: "Inferno Genesis Keys"
description: "一款去中心化的 PvE/PvP 游戏，背景是 Dante Alighieri 的《神曲》的黑暗奇幻改编。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "inferno-genesis-keys.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://app.infernoverse.com/home/mint"
twitter: ""
discord: "https://discord.gg/theinfernoverse"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
进入 Inferno - 一款分散的 PvE/PvP 游戏，背景是 Dante Alighieri 的《神曲》的黑暗奇幻改编。 Inferno 提供了一种坚韧不拔、叙事驱动的战斗竞技场体验，强调基于技能的竞争性游戏玩法，并通过玩家驱动的手工艺经济得到加强。 解锁元素力量，制作强大的物品以用于战斗，并在为天堂或地狱的荣耀而战时升级你的角色。Inferno Genesis Keys 是 12,000 个早期采用者 NFT 的集合，它们对应于十二生肖之一（ Inferno 中的“类”）。 这些钥匙可在开发的每个阶段解锁 Infernoverse 的主要功能，从独家的创世纪盔甲套装开始。

![nft](1661597176970(1).png)