---
title: "Interludes and quietudes"
description: "“Interludes and quietudes”承认发生在大思想之间的生活中的小事件"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "interludes-and-quietudes.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/interludes-and-quietudes"
twitter: "https://www.twitter.com/LizaHawthorne"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/lizahawthorneartist"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
“Interludes and quietudes”承认发生在大思想之间的生活中较小的事件。 每幅肖像都探索了章节之间的停顿。 一个存在于当下的时间。 通过大量富有表现力的颜色和图案，不断收集智慧和观察。 所有艺术品都以混合媒体模拟绘画开始。 1/1。 智能合约。本网站上的数据来自各种 NFT 市场和 NFT 项目创建者自己。 我们还直接从 Twitter 和 Discord 获取 NFT 社区统计数据。每幅肖像都探索了章节之间的停顿。

![nft](1661600740306(1).png)