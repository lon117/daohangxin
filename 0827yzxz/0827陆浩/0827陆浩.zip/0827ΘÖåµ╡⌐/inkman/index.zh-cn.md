---
title: "InkMan"
description: "少点眼花缭乱。 得到一个墨水人。 少即是多。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "inkman.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/inkman"
twitter: "https://www.twitter.com/InkmanArt"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是墨水人？
InkMan 是一个 NFT（不可替代令牌）集合。 存储在区块链上的数字艺术品集合。
▶ 有多少 InkMan 代币？
总共有 1,001 个 InkMan NFT。 目前，481 位所有者的钱包中至少有一个 InkMan NTF。
▶ 最昂贵的 InkMan 销售是什么？
售出的最昂贵的 InkMan NFT 是 InkMan #75。 它于 2022 年 6 月 26 日（2 个月前）以 24.7 美元的价格售出。
▶ 最近卖出了多少 InkMan？
过去 30 天内售出了 25 个 InkMan NFT。
▶ InkMan 的价格是多少？
在过去 30 天里，最便宜的 InkMan NFT 销售额低于 11 美元，最高销售额超过 21 美元。 InkMan NFT 在过去 30 天内的中位价格为 14 美元。
▶ 流行的 InkMan 替代品有哪些？
许多拥有 InkMan NFT 的用户还拥有 THE FUNKY CATS、KOI POND | Ichigo Tamagashi 的，Battle Derps 和您好客人！！。
  交互式 NFT 项目：Goofball Gang。 立即购买。

![nft](1661599474518(1).png)
