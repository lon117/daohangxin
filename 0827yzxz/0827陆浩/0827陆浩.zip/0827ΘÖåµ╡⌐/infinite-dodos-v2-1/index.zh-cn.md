---
title: "The Infinite Dodos (Dead)"
description: "Dead Infinite Dodos 来拿 DodoVerse！"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "infinite-dodos-v2-1.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.infinitedodos.com/"
twitter: "https://www.twitter.com/InfiniteDodos"
discord: "https://discord.gg/QdxTzPNB"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/infinitedodos/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是无限渡渡鸟（死亡）？
Infinite Dodos (Dead) 是一个 NFT (Non-fungible token) 集合。 存储在区块链上的数字艺术品集合。
▶ 有多少 The Infinite Dodos (Dead) 代币？
总共有 133 个 The Infinite Dodos (Dead) NFT。 目前，90 位所有者的钱包中至少有一个 The Infinite Dodos (Dead) NTF。
▶ The Infinite Dodos (Dead) 销售中最昂贵的是什么？
出售的最昂贵的 The Infinite Dodos (Dead) NFT 是 Infinite Dodos #14。 它于 2022 年 6 月 21 日（2 个月前）以 225.8 美元的价格售出。
▶ 最近卖出了多少只 The Infinite Dodos (Dead)？
过去 30 天内售出了 2 个 The Infinite Dodos (Dead) NFT。

![nft](1661597411610(1).png)
