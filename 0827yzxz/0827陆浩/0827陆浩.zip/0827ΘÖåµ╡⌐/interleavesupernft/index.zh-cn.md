---
title: "Interleave superNFT"
description: "这个 superNFT 是您铸造 6 件为 Interleave 创作的艺术品的访问令牌。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "interleavesupernft.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.interleavestudios.io/"
twitter: ""
discord: "https://discord.gg/EfFRmq47su"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是 Interleave superNFT？
Interleave superNFT 是一个 NFT (Non-fungible token) 集合。 存储在区块链上的数字艺术品集合。
▶ 存在多少 Interleave superNFT 代币？
总共有 1 个 Interleave superNFT NFT。 目前 150 位所有者的钱包中至少有一个 Interleave superNFT NTF。
▶ 最昂贵的 Interleave superNFT 销售是什么？
售出的最昂贵的 Interleave superNFT NFT 是 . 它于 2022 年 6 月 8 日（3 个月前）以 120 美元的价格售出。
▶ 最近卖出了多少 Interleave superNFT？
过去 30 天内售出了 2 个 Interleave superNFT NFT。
▶ 流行的 Interleave superNFT 替代品有哪些？
许多拥有 Interleave superNFT NFT 的用户还拥有 Interleave Productions、Dirty Robot Interleave Artwork、The 8102: Yachts 和 WAGDIE Tokens Of Concord。

![nft](1661600887626(1).png)