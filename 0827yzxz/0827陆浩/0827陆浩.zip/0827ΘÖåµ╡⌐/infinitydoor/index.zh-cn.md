---
title: "Sunmiya Club - Infinity Door"
description: "随着某处传来的声音，漫长的旅程开始了。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "infinitydoor.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://sunmiya.club/"
twitter: "https://www.twitter.com/SunmiyaClub"
discord: "https://discord.gg/sunmiyaClub"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
随着某处传来的声音，漫长的旅程开始了。
由 3 种类型组成的无限门以每个 Miya 1:1 的比例随机分布。
Miyas 将通过无限门传送到不同的星球。 可以通过合成无限门、米娅和 280 人情来实现扭曲。
综合时间表将在 AMA 之后公布。 漫长的旅程开始了，跟随从某个地方传来的声音。
每个 MIYA 包含 3 种类型的无限门将随机空投和
MIYA 将分别传送到其他行星。 可以通过合成Infinity Door，MIYA和280 Favor来完成翘曲。
综合时间表将在 AMA 之后公布。

![nft](1661597698353(1).png)

