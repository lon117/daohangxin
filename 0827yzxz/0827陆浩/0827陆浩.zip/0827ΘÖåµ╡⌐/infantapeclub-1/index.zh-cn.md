---
title: "InfantApeClub"
description: "官方婴儿猿俱乐部"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "infantapeclub-1.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/infantapeclub-1"
twitter: "https://www.twitter.com/InfantApeCLUB"
discord: "https://discord.gg/KsSZag9qFU"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/infantapeclub/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
官方 Infant Ape Club Opensea！，婴儿猿旅行以太寻找他们的收藏家，带着他们独特的特征和可爱的怪癖。 但是不要让它们可爱的脸蛋欺骗了你，婴儿猿携带着一条扭曲的 DNA 基因链，当收集到最后一个婴儿时，它就会变得活跃。 收养婴儿猿的收藏家可能会手忙脚乱……变异的婴儿猿可不是什么笑料。 给婴儿猿一个家并拥抱突变体，谁知道......也许会发现改变那些突变体。

![nft](1661596581833(1).png)