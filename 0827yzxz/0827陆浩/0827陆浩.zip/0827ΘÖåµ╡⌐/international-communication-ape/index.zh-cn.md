---
title: "International Communication Ape"
description: "在一个绿色的猩猩星球上，有 9999 只猩猩"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "international-communication-ape.gif"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/international-communication-ape"
twitter: "https://www.twitter.com/jgkg11630780"
discord: "https://discord.gg/E7cVrGFXhm"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
在一个绿色的人猿星球上，有 9999 只猿在自己的土地上战斗，创造了猿人时代。 繁衍不断，战争不断，各种对死亡的恐惧，他们正式出动国际社会猿，呼吁和平解决战争，最终达成协议。 （其余各为 0.0015）本网站上的数据来自各种 NFT 市场和 NFT 项目创建者自己。 我们还直接从 Twitter 和 Discord 获取 NFT 社区统计数据。关于在 Twitter 上关注我们@NFT_tracker加入我们的 NFT Stats Discord ServerNFT Creators：列出你的 NFT 项目

![nft](1661600554756(1).png)

