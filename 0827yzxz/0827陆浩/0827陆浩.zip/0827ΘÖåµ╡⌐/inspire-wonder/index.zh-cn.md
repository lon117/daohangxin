---
title: "Inspire Wonder"
description: "作为一名摄影师，艺术和想象力驱使我去创作； 但鼓舞人心的奇迹使我茁壮成长。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "inspire-wonder.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://glennleerobinson.com/"
twitter: "https://www.twitter.com/glennleerob"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/glennleerobinson"
reddit: ""
medium: "https://www.medium.com/@glennleerobinson"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
作为一名摄影师，艺术和想象力驱使我去创作； 但鼓舞人心的奇迹使我茁壮成长。▶ 什么是激发奇迹？
Inspire Wonder 是一个 NFT（非同质代币）集合。 存储在区块链上的数字艺术品集合。
▶ 有多少 Inspire Wonder 代币？
总共有 10 个 Inspire Wonder NFT。 目前 8 位所有者的钱包中至少有一个 Inspire Wonder NTF。
▶ 最近卖出了多少 Inspire Wonder？
过去 30 天内售出了 0 个 Inspire Wonder NFT。本网站上的数据来自各种 NFT 市场和 NFT 项目创建者自己。

![nft](1661600151318(1).png)