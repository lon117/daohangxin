---
title: "GUMBINO"
description: "虚拟世界中最愚蠢的婴儿。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gumbino.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://app.rarible.com/collection/0x4bc2d477758edbfc658af18b6283268b69919bad"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/olivierjeanp/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是甘比诺？GUMBINO 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。▶ 有多少 GUMBINO 代币？总共有 26 个 GUMBINO NFT。目前，55 位所有者的钱包中至少有一个 GUMBINO NTF。▶ 最近卖出了多少 GUMBINO？过去 30 天内售出 0 个 GUMBINO NFT。gUmbino，虚拟世界中最愚蠢的婴儿。采用gUmbino！头发轻弹黑色：11.5%玻璃：3.8%模糊绿色：3.8%陶瓷粉色：3.8%亮黑色：15.4%陶瓷黑：7.7%陶瓷橙：3.8%陶瓷海军蓝：3.8%瞳孔颜色蓝色：7.7%黑色：46.2%绿色：3.8%黄色：3.8%背景色白色：73.1%

![nft](1661595197228(1).png)