---
title: "Infernal Vampire Colonys"
description: "欢迎来到 OpenSea 上的地狱吸血鬼殖民地之家"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "infernal-vampire-colonys.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.infernalvampires.com/"
twitter: "https://www.twitter.com/IVCNFT"
discord: "https://discord.gg/IVCNFT"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
欢迎来到 OpenSea 上的地狱吸血鬼殖民地之家。 发现此系列中最好的物品。 666 名被困在洞穴中多年的吸血鬼成功逃脱▶ 什么是吸血猿集团？
Vampire Ape Syndicate 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。
▶ 有多少吸血猿辛迪加代币？
总共有 3,000 个 Vampire Ape Syndicate NFT。目前，282 位所有者的钱包中至少有一个 Vampire Ape Syndicate NTF。
▶ 最近卖了多少吸血猿集团？
过去 30 天内共售出 0 个 Vampire Ape Syndicate NFT。

![nft](1661596815607(1).png)