---
title: "Bored Ape Impact Club V2"
description: "什么是无聊的猿冲击俱乐部 V2？"
date: 2022-08-26T00:00:00+08:00
lastmod: 2022-08-26T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "bored-ape-impact-club-v2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://web.facebook.com/groups/525118262601185"
twitter: "https://www.twitter.com/plugaru_raul"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/boredapeimpactclub/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Bored Ape Impact Club，30个独特的NFT，此版本的持有者在索赔期到来时将获得以下Bored Ape Impact Friend产品：Bored Ape Impact Club V2 NFT - 常见问题（FAQ）
▶ 什么是无聊的猿冲击俱乐部 V2？
Bored Ape Impact Club V2 是一个 NFT（替代令牌）集合。存储在区块链上不可链上的数字收藏品集合。
▶ 有多少 Bored Ape Impact Club V2 代币？
2个Bored Impact Club V2有30个Bored Impact Club。目前2个N位的Ape Impact Club中至少有一个Bored Impact V2。
▶最近一次冲击了多少 Club V2？
过去 30 个经典的 N 款 0 个 Bored Impact Club V2。

![nft](unnamed.png)