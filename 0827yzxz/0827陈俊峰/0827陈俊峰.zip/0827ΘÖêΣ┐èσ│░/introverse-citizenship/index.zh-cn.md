---
title: "Introverse Citizenship"
description: "Introverse 由以太坊区块链上的 1,555 个 Boobles 组成。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "introverse-citizenship.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://introverse.club/"
twitter: "https://www.twitter.com/_introverse_"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/__introverse___"
reddit: ""
medium: "https://www.medium.com/@_Introverse_"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Introverse 由以太坊区块链上的 1,555 个 Boobles 组成。我们是一个社区和一个运动，其中心是为所有内向的公民在他们生活的不同方面增加价值。内向公民 NFT - 常见问题（FAQ）
▶ 什么是内向公民？
Introverse Citizenship 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字收藏品集合。
▶ 有多少 Introverse Citizenship 代币？
在Ntroverse Citizenship 204现在，11个FT的钱包中至少有一个Introverse Citizenship NT。
▶ 最昂贵的 Introverse Citizenship 销售是什么？
出品的最贵的 Introverse Citizenship NFT 是 INTROVERSE #119。它于 2022-06-06（3 个月前）以 1.8 美元的价格售出。
▶最近抽象了多少内向公民
过去 30 条介绍 3 个 Intro Citizenship NFT。![unnamed](C:\Users\陈俊峰\Desktop\0826陈俊峰100条\introverse-citizenship\unnamed.png)