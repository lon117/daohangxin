---
title: "In The Shadows // Edition of 40"
description: " 什么是在阴影中//第 40 版？"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "intheshadowsedition.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://twitter.com/kristophershinn"
twitter: "https://www.twitter.com/kristophershinn"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/kristophershinn/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
In The Shadows // 40 NFT 版 - 常见问题（FAQ）
▶ 什么是在阴影中//第 40 版？
In The Shadow 版本//第 40 代是 NFT（代币）集合存储。不可在链上的数字收藏品集合。
▶ 有多少 In The Shadows // 40 代币版本？
一个影子的版本，// 40 NFT 1 个版本目前39 个影子中至少有一个影子。//////
▶最近售出多少 In The Shadows // 40 版？
过去 30 个版本的售卖 40 个 // 0 个 NFT 版本。
▶在中流行什么// 40种替代版本？
拥有 In The Shadows // 40 NFT 版的用户还拥有顺风顺水版、 Timeless Fog x Cody Mayer 版、 Joelle LB 版和 Ethan Lington 版。

![nft](1500x500.jpg)