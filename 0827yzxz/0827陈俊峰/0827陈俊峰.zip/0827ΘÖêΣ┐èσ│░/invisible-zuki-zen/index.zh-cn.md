---
title: "IZUKI ZEN"
description: "Mint 于 2022 年 4 月 13 日 15:00 UTC 上线。我们是 ETH 区块链上的衍生项目，拥有 10.000 IZUKI。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "invisible-zuki-zen.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.twitter.com/invsblezuki"
twitter: "https://www.twitter.com/invsblezuki"
discord: "https://discord.gg/izukizen"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Mint 于 2022 年 4 月 13 日 15:00 UTC 上线。我们是 ETH 区块链上的衍生项目，拥有 10.000 IZUKI。IZUKI 是一个社区驱动的项目！IZUKI ZEN NFT - 问题常见（FAQ）
▶ 什么是伊豆禅？
IZUKI ZEN 是一个 NFT（Non-fungible token）集合。在区块链上的数字收藏品存储集合。
▶ 存在多少IZUKI ZEN 代币？
ZEN5个NT2，47个IZUKIEN NFT。目前7位车的钱包中至少有一个IZUKI。
▶ IZUKI ZEN 最昂贵的促销活动是什么？
出价最贵的 IZUKI ZEN NFT 是 IZUKI #1253。它于 2022 年 6 月 17 日（2 个月前）以 0 美元的价格出售。
▶最近最近了多少？
过去30个卖出UKI 1个IZEN NFT。
▶ 流行的 IZUKI ZEN 替代品有哪些？
拥有IZUKI ZEN NFT的用户还拥有IZUKI ZEN、Dripperz CyberClub、Fashion Dog Official NFT和Dreamer Girl Official。

![nft](unnamed.png)