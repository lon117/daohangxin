---
title: "Invisible Friends Official"
description: "什么，谁，在哪里？KITH 隐形朋友，真的吗？那是什么？"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "invisibelfriends1000.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://invisiblefriends.io/"
twitter: "https://www.twitter.com/InvsbleFriends"
discord: "https://discord.gg/rndm"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/invisiblefriends_io"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么，谁，在哪里？KITH 隐形朋友，真的吗？那是什么？五月你就知道了。持有人的优先访问权。在夏季结束时，所有 IF 持有者将有机会铸造一个由 Nguyen Nhut 制作的具有新旧随机特征的 3D 隐形朋友。请继续关注有关发布的更多信息。玩具，玩具，玩具！！！谁不喜欢玩具！？不可能是我们！这就是为什么我们将我们的 OG Friend 带入现实世界，并让我们的 3D 持有者有机会为他们的收藏抓住这个未来的经典之作。它会涉及自己的 NFT 吗？HODL 并找出答案！

![nft](unnamed (1).png)