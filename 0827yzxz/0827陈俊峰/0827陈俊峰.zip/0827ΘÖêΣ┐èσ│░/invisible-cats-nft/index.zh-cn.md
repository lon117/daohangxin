---
title: "InvisibleCats"
description: "隐形猫是以太坊区块链上 5,000 个随机生成的 NFT 的集合。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "invisible-cats-nft.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/invisible-cats-nft"
twitter: "https://www.twitter.com/InvsbleCatsNFT"
discord: "https://discord.gg/Rh5SumgtwU"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/invisiblecats_nft"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
隐形猫是以太坊区块链上 5,000 个随机生成的 NFT 的集合。 Invisible Cats 持有者将在 Mint 开始后的 1 周内获得独家免费领取 Invisible Pets 掉落。这个系列是酷猫和隐形朋友的衍生品。InvisibleCats NFT - 常见问题（FAQ）
▶ 什么是隐形猫？
InvisibleCats 是一个 NFT（非同质代币）集合。存储在区块链上的数字收藏品集合。
▶ 有多少 InvisibleCats 代币？
有 1,195 个隐形 Cat。 目前，89 个 N 个 F 位的钱包中至少有一个 NTF。
▶ 近期猫？
过去 30 个 认购 C 0 个 Invisibleats NFT。

![nft](unnamed.png)

