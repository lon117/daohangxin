---
title: "Intersectional Abstraction"
description: "Intersection Abstraction 是限量发行的高分辨率手绘 4k 冥想作品，探讨了创造我们的有机宇宙与我们自己创造的数字宇宙之间的关系。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "intersectional-abstraction-by-pscarlyle.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/intersectional-abstraction-by-pscarlyle"
twitter: "https://www.twitter.com/pscarlyle"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Intersection Abstraction 是限量发行的高分辨率手绘 4k 冥想作品，探讨了创造我们的有机宇宙与我们自己创造的数字宇宙之间的关系。交叉抽象 NFT - 常见问题（FAQ）
▶ 什么是交叉抽象？
Intersection Abstraction 是一个 NFT（不可替代代币）集合。存储在区块链上的数字收藏品集合。
▶ 存在多少交叉抽象代币？
6个有N个交叉点的交叉点。目前有N个交叉点的N个交叉点。
▶ 离子抽象？
过去 30 款售出 0 个对比 NFT。

![nft](unnamed.png)