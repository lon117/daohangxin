---
title: "BoredApe Punks"
description: "Bored Ape Punks 是 1,000 个 Ape Punks 的独家系列。"
date: 2022-08-26T00:00:00+08:00
lastmod: 2022-08-26T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "bored-ape-punks-nfts.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://linktr.ee/boredapepunks"
twitter: "https://www.twitter.com/ApePunkNFTs"
discord: "https://discord.gg/Nth6veKxcj"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Bored Ape Punks 是 1,000 个 Ape Punks 的独家系列。在 Polygon 上铸造，享受您最喜欢的无气猿朋克！BoredApe Punks NFT - 问题常见（FAQ）
▶ 什么是无聊猿朋克？
BoredApe Punks 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字收藏品集合。
▶ 有多少 BoredApe Punks 代币？
1个Punks BoredApe NFT，100个Punks BoredApeF。目前95位车的钱包中至少有一个。
▶最近很有趣吗？
过去30个共售出0个Borpe Punks N个。通用！我们几乎卖光了！路线图很快就出来了！！

![nft](unnamed.png)