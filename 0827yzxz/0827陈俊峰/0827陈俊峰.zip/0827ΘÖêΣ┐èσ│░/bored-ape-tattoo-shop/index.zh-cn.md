---
title: "Bored Ape Tattoo Shop"
description: "曾经觉得无聊的猿缺少什么吗？"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "bored-ape-tattoo-shop.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/bored-ape-tattoo-shop"
twitter: "https://www.twitter.com/BATS_nft"
discord: "https://discord.gg/kSsty6FAT3"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
曾经觉得无聊的猿缺少什么吗？

是的，我们也是。一些很酷的纹身。这就是我们创建无聊猿纹身店的原因；1,999 只纹身猿的集合，正在寻找一些纹身鉴赏家。无聊动漫纹身店 NFT - 常见问题（FAQ）
▶ 什么是无聊的纹身店？
Bored Ape 纹身系列店是一个 NFT（非同质代币）。存储在区块链上的数字收藏品集合。
▶ 有多少无聊的纹身店代币？
1家店有Bored Ape纹身店NFT。目前店主的钱包里至少有一个Bored Ape纹身店NFT。
▶最近卖了多少无聊的动漫纹身店？
过去30款Bort共售出0款Borpe纹身店。

![nft](unnamed.png)