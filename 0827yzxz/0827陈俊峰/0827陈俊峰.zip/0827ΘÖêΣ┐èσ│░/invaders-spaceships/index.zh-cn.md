---
title: "Invaders Spaceships"
description: "2021 年 9 月 10 日，五角大楼发布了 Gray Disclosures 51 论文。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "invaders-spaceships.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://invaders.earth/"
twitter: "https://www.twitter.com/invadersnft"
discord: "https://discord.gg/CsxKnkSnqp"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
2021 年 9 月 10 日，五角大楼发布了 Gray Disclosures 51 论文。它证实了我们中间存在外星人，他们小心翼翼地伪装成平民。他们的目标：全面入侵和殖民地球（那是我们的星球，对于那些没有天文学博士学位的人来说）。目前我们中间有10,000名入侵者。我们正在向你们，平民居民寻求帮助。您必须捕获一个外星人并将其放在钱包中以供进一步研究。在它们全部被中和之前，我们的星球将不安全。
我们所知道的生命的未来取决于你...

![nft](unnamed (1).jpg)