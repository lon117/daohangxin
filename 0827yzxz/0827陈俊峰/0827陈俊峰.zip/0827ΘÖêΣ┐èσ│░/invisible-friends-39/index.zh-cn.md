---
title: "Invisible Friends"
description: "隐藏在元宇宙中。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "invisible-friends-39.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://invisiblefriends.io/"
twitter: "https://www.twitter.com/InvsbleFriends"
discord: "https://discord.gg/rndm"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/invisiblefriends_io"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
隐藏在元宇宙中。

Invisible Friends 是由 Markus Magnusson 创作的 5000 个动画隐形角色的集合。

隐形朋友是一个随机角色集体项目。隐形朋友 NFT - 常见问题（FAQ）
▶ 什么是隐形朋友？
Invisible Friends 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字收藏品集合。
▶ 有多少隐形朋友代币？
在有 5,00 个隐形朋友。目前，3,968 个隐形朋友的钱包中至少有一个 NTF。
▶ 什么是最昂贵的隐形朋友销售？
销售的最贵的 Invisible Friends NFT 是 Invisible Friends #1776。它于 2022 年 6 月 23 日（2 个月前）以 2.85 万美元售出。
▶最近卖了多少隐形朋友？
过去 30 个用户售出 321 个可见好友 NFT。
▶ 隐形朋友要多少钱？
在过去的天里，Invisible Friends NFT 的最便宜的 3 天为 2915 美元，最高 5900 美元。过去 30 天，Invisible Friends NFT 的中位价格为 3842 美元。
▶ 什么是流行的隐形朋友品？
拥有 Invisible Friends NFT 的用户还拥有 SlimHoods、Lucas Zanotto 的 MoodRollers、Kith Friends 和 Mood Flippers。

![nft](unnamed (1).png)