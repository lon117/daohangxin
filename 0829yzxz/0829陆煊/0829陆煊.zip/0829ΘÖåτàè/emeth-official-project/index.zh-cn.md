---
title: "EMETH OFFICIAL PROJECT"
description: "EMΞTH 是在以太坊区块链上调用的 8,888 个独特魔像的集合。"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "emeth-official-project.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/emeth-official-project"
twitter: "https://www.twitter.com/emeth_project"
discord: "https://discord.gg/emeth"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/emethproject//"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
EMΞTH 是在以太坊区块链上调用的 8,888 个独特魔像的集合。魔像在史诗般的战斗中为保护他们的社区而战，这将被世世代代铭记。Golems 和其他主要 NFT 社区之间将定期组织战斗。‍ 每场战斗都有机会收集与其他社区合作制作的记忆和独特的 NFT。这是一个新概念，我们称之为：玩收集Golems 和其他主要 NFT 社区之间将定期组织战斗。‍ 每场战斗都有机会收集与其他社区合作制作的记忆和独特的 NFT。

![nft](1.png)

