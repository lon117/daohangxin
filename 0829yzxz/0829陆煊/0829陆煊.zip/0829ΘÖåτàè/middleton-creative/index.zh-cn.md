---
title: "Middleton Creative"
description: "因为这是我作为 NFT 制作的 IRL 视频创作的开始，所以这个必须是特别的。"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "middleton-creative.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/middleton-creative"
twitter: "https://www.twitter.com/MiddletonCREATV"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/middletoncreative/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
因为这是我作为 NFT 制作的 IRL 视频创作的开始，所以这个必须是特别的。2021 年仲冬，我正在测试我的新 360 度全景相机，因此创造了一些真正独特的东西。从来没有想过我会把它变成我的 Genesis NFT。Middleton Creative NFT - 常见问题（FAQ）
▶ 什么是米德尔顿的创意？
Middleton Creative 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字收藏品集合。
▶ 有多少 Middleton Creative 代币？
目前有2位Creative的中至少有一个Middleton NTF。
▶最近多少了 Middleton Creative
过去30个Middleton共售出0个Creative NFT。

![nft](1.png)

