---
title: "Embers Officially"
description: "IMX 迁移。您可以通过我们的网站正式开始将您的资产迁移到 IMX，以获得您土地的全部价值！"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "embers-nft-official-genesis.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/embers-nft-official-genesis"
twitter: "https://www.twitter.com/PlayEmberSword"
discord: "https://discord.gg/embersword"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Ember Sword 是一款社交沙盒 MMORPG，发生在玩家驱动的宇宙中，冒险会找到你。Ember Sword 由富有想象力的艺术家、工程师和游戏设计师团队打造，提供独特的社区主导和无摩擦的 PvP 和 PVE 玩家体验，并让玩家真正拥有数字游戏资产。玩家可以一起进行史诗般的冒险，并分享经验和知识。他们可以选择通过击败怪物、老板和其他玩家来证明自己的价值和技能。他们还可以选择作为和平的商品和收藏品的觅食者探索世界。你做什么和什么时候完全取决于你！每种武器类型都有自己的相关技能，其他 RPG 元素（如制作）也是如此。Ember Sword 将包含具有挑战性的 PVE 终局游戏、硬核 PvP、活生生的经济等等！

![nft](1.png)