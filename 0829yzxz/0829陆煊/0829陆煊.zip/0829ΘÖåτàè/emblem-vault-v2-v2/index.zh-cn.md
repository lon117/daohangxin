---
title: "Emblem.Finance"
description: "Emblem Vault 是 NFT 容器，可以包含一个或多个令牌，或 NFT"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "emblem-vault-v2-v2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://emblem.pro/"
twitter: "https://www.twitter.com/EmblemVault"
discord: ""
telegram: "https://t.me/Coval_Chat"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Emblem Vault 是 NFT 容器，可以包含一个或多个令牌，或 NFT将不同的区块链代币组合成一个代币。可交易的 DeFi 矿池。使任何令牌成为隐私令牌。制作可交易的投资组合。区块链的第一个 复合代币Emblem Vault 是一种完全去中心化的代币，旨在以最简单的方式解决问题。在任何基于 EVM 的区块链（Fantom、Eth、BSC + 更多）上交易来自任何区块链的代币同时交易多个代币作为一个代币不仅交易代币，还交易数字文件，通过创建包含多个代币的保险库来制作对冲代币

![nft](1.png)