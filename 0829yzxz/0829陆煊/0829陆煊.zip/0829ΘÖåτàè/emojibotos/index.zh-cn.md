---
title: "Emojibotos"
description: "机器人也有感情！在这个系列中，Robotos 以表情符号的形式表达他们的情感。"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "emojibotos.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.robotos.art/"
twitter: "https://twitter.com/robotosnft"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Robotos 是由[Pablo Stanley]设计并铸造为 NFT 的机器人角色集合。它们由各种金属服装、锡面、数码配件、上衣、脸、背包、武器和颜色构成。得到你自己的！每个 NFT 都是通过将 170 多个独特特征与不同类别的稀有性相结合而通过算法生成的。Robotos 是由[Pablo Stanley]设计并在以太坊区块链上作为 NFT 铸造的算法生成的机器人角色集合。第一代 10,000 个机器人将由各种金属服装、锡面、数码配件、上衣、面孔、背包、手臂和颜色构成。机器人有不同的体型，有些比其他的更罕见，而且……有传言说你也可以发现人类伪装成机器人。这是真的吗？

![nft](1.png)