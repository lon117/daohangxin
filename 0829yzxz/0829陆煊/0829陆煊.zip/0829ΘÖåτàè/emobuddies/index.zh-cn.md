---
title: "Emo Buddies"
description: "Emo Buddies 不仅仅是 2000 个随机生成的 NFT 的集合。"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "emobuddies.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/emobuddies"
twitter: "https://www.twitter.com/EmoBuddiesNFT"
discord: "https://discord.gg/emobuddies"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/EmoBuddiesNFT/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Emo Buddies 不仅仅是 2000 个随机生成的 NFT 的集合。我们的社区专注于将人们聚集在一起表达他们的情感并在更深层次上相互体验。快乐、悲伤、焦虑或介于两者之间的任何事情，Emo Buddies 提供社区资源，以有趣、令人兴奋和有影响力的方式促进其成员的心理、情感和身体健康。欢迎来到以太坊区块链上最令人振奋的新项目！请继续关注史诗般的赠品、商品掉落、聚会、奖品等等。在多年被同学误解后，来自世界各地的 Emo Buddies 毕业并发现自己身处“现实世界”。在这里，他们很快发现并没有太大变化。无处可去，他们能否走到一起，分享他们的天赋并建立一个成功的社区？或者，受欢迎的孩子一直都是对的……？加入 Buddies，开始寻找被遗忘的 Buds，向世界展示“emo”的真正含义。

![nft](1.png)