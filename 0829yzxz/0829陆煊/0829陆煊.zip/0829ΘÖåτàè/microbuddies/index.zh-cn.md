---
title: "MicroBuddies"
description: "MicroBuddies是一款由Polygon提供支持的NFT 策略游戏。花费你的微生物产生的GOO来创造产生更多GOO的稀有微生物。"
date: 2022-08-29T00:00:00+08:00
lastmod: 2022-08-29T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "microbuddies.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/microbuddies"
twitter: "https://www.twitter.com/MicroBuddies"
discord: "https://discord.gg/microbuddies"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
MicroBuddies是一款由Polygon提供支持的NFT 策略游戏。花费你的微生物产生的GOO来创造产生更多GOO的稀有微生物。2021 年，在废弃的纳米工厂中发现了 2500 种新型微生物。有 10 种独特的物种，每一种都具有独特的基因构成，并且能够从自己的副产品中自我复制：GOO！

由于它们可爱的行为，这些微生物以及它们之后的所有微生物都被称为 MicroBuddies TM。

在游戏过程中，每次复制都会产生下一代 MicroBuddy - 具有独特的外观和增强的 GOO 生产。

MicroBuddies 正在通过扩展到 Robolox 来扩大其人口范围！

以 MicroBuddies 为主题的虚拟世界体验旨在通过让游客沉浸在引人入胜的任务、有趣的竞赛和竞技游戏中来捕捉想象力。

用户可以角色扮演采矿硬币和GOO，购买角色升级和助推器，并在玩家排名上升的同时赢得独特和稀有的物品！

![nft](1.png)