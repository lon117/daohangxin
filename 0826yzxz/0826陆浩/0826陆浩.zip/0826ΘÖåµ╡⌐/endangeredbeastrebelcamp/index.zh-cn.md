---
title: "Endangered Beast Rebel Camp"
description: "欢迎来到濒危野兽叛军营地。"
date: 2022-08-26T00:00:00+08:00
lastmod: 2022-08-26T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "endangeredbeastrebelcamp.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/endangeredbeastrebelcamp"
twitter: "https://www.twitter.com/NFTjungleco"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/nftjunglecollective"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
欢迎来到濒危野兽叛军营地。

随着他们的数量不断减少，濒临灭绝的野兽叛军在叛军营地联合起来，寻找新兵来对抗偷猎者和栖息地破坏。

NFT 丛林集体项目濒临灭绝的野兽反叛营 (ERBC) 以社区捐赠、同志情谊和帮助世界上一些最濒危的动物为前提。请访问了解更多信息。

这一下降将包括 3,333 个独特的 NFT，以编程方式随机化，存储为以太坊区块链上的 ERC-721 代币，并托管在 IPFS 上

![nft](unnamed.jpg)