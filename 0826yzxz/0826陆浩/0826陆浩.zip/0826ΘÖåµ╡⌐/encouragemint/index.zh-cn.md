---
title: "Encouragemint"
description: "Word of Encouragemint 是 ERC-721 NFT，具有积极的链上氛围，可帮助您度过艰难时期。"
date: 2022-08-27T00:00:00+08:00
lastmod: 2022-08-27T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "encouragemint.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/encouragemint"
twitter: "https://twitter.com/hashtag/encouragement"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Word of Encouragemint 是 ERC-721 NFT，具有积极的链上氛围，可帮助您度过艰难时期。我们希望将一些积极性带回我们喜爱的空间，因此我们整理了一个免费薄荷糖（不包括汽油费），让您的一天变得更好。 Mint Words of Encouragemint 让您的以太坊钱包成为一个快乐的地方。当您使用它时，向您的朋友发送一些代币。SMART CONTRACT 利用 ERC721A，铸造一个或铸造多个代币应该花费几乎相同的汽油费。这是一个免费的薄荷糖（不包括汽油费），所以请不要害羞，尽可能多地薄荷糖。

![nft](1.png)