---
title: "ENCRYPTED GODS - MALE"
description: "Encrypted Gods 是以太坊区块链上独特生成的像素艺术战士的 NFT 集合。第一代由 9,999 个男性化身组成"
date: 2022-08-26T00:00:00+08:00
lastmod: 2022-08-26T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "encryptedgods-male.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/encryptedgods-male"
twitter: "https://www.twitter.com/EncryptedGods_"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/encryptedgodsnft"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Encrypted Gods 是以太坊区块链上独特生成的像素艺术战士的 NFT 集合。第一代由 9,999 个男性化身组成。铸造/购买您的角色，玩我们即将推出的游戏，赚取我们的原生代币，并在我们计划的元宇宙中创建您自己的世界。现在 PFP，明天元界化身 - 今天铸造你的战士，加入我们的战斗！计划中的效用将是 PVP、地牢、虚拟世界和创新的游戏玩法。这个项目是基于社区的，在我们创建初始模式和元宇宙之后，我们将寻求让社区提交他们的神和文化以在游戏中实施。我们创建了自己的语言，名为“加密”，并将在游戏中用于特殊用途。我们希望通过我们的游戏和社区赋予女性权力并为她们提供一个平台。加密家庭欢迎所有人哦，我们提到水晶了吗？

![NFT](1661495596737.jpg)