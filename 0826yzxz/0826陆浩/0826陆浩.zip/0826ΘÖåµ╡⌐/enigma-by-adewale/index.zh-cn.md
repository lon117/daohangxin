---
title: "ENIGMA by Adewale"
description: "每幅画都是对潜意识的短暂本质以及超越它的事物的表达/研究"
date: 2022-08-26T00:00:00+08:00
lastmod: 2022-08-26T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "enigma-by-adewale.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/enigma-by-adewale"
twitter: "https://www.twitter.com/_AdewaleMayowa"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/_adewalemayowa"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ Adewale 的 ENIGMA 是什么？
Adewale 的 ENIGMA 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。
▶ 存在多少 ENIGMA by Adewale 代币？
Adewale NFT 总共有 3 个 ENIGMA。目前 8 位所有者的钱包中至少有一个 ENIGMA by Adewale NTF。
▶ Adewale 拍卖中最昂贵的 ENIGMA 是什么？
Adewale NFT 出售的最昂贵的 ENIGMA 是 ENIGMA 1。它于 2022-08-16（10 天前）以 140.7 美元的价格售出。
▶ Adewale 的 ENIGMA 最近卖出了多少？
在过去 30 天内，Adewale NFT 出售了 3 个 ENIGMA。

![nft](1661500543679.jpg)