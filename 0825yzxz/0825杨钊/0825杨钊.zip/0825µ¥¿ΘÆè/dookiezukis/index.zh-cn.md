---
title: "DookieZuki"
description: ""
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dookiezukis.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/dookiezukis"
twitter: "https://www.twitter.com/DookieZuki"
discord: "https://discord.gg/dookiZuki"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**dookieZuki.wtf 统计**
创建于 5 个月前，481代币供应，7.5% 费用
过去 7 天内没有出售 dookieZuki.wtf。

一组新的战士出现了——冷静，但在需要时会爆发；硬 AF，但也很软……在心里；快如闪电，却能如愿以偿。此外，他们只是非常优秀的游泳运动员......网站：https ://dookiezuki.io/

### dookieZuki.wtf NFT - 常见问题（FAQ）

##### ▶ 什么是dookieZuki.wtf？

dookieZuki.wtf 是一个 NFT (Non-fungible token) 集合。存储在区块链上的数字艺术品集合。

##### ▶ 存在多少个dookieZuki.wtf 代币？

总共有 481 个 dookieZuki.wtf NFT。目前 177 位所有者的钱包中至少有一个 dookieZuki.wtf NTF。

##### ▶ 最近卖了多少dookieZuki.wtf？

过去 30 天共售出 0 个 dookieZuki.wtf NFT。

##### ▶ 什么是流行的 dookieZuki.wtf 替代品？

许多拥有 dookieZuki.wtf NFT 的用户还拥有 [MEKAZUKI GENESIS]、 [SkllFckrs]、 [3D Martians]和 [Bored Gutter Apes Gen 2]。

![nft](unnamed.png)