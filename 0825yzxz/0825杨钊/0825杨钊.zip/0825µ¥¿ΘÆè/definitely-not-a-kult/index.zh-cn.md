---
title: "Definitely not a Kult"
description: "我们不是 KULT！但你可以为事工牺牲你宝贵的东西。"
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "definitely-not-a-kult.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://definitelynotakult.io/"
twitter: "https://www.twitter.com/DefoNotAKult"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**绝对不是 Kult 统计数据**

创建于 3 个月前，509代币供应，5% 费用

在过去的 7 天里绝对没有售出 Kult。

我们不是 KULT！但你可以为事工牺牲你宝贵的东西。每天晚上我们都会举行仪式，直到黑暗领主崛起！而我们奴才将成为更高的生命体和无与伦比的能力。

加入我们的兄弟姐妹，我们将使这个残酷的世界成为一个没有弱点的地方。

我们中的一员！！我们中的一员！！我们中的一员！！我们中的一员！！我们中的一员！！

绝对不是 Kult NFT - 常见问题（FAQ）
▶什么是绝对不是Kult？
绝对 Kult 是 NFT（不可替代）集合。不是在区块链上的数字收藏品集合。
▶ 存在多少绝对不是Kult代币？
NT有509个绝对不是Kult NFT，63位的绝对中至少有一个KultF。
▶ 最贵的绝对不是 Kult 销售是什么？
卖的最贵的绝对不是Kult NFT 不是Kult #268。它于2022-06-11（3月前）以30.1美元的价格售出。
▶ Kult？ 肯定不是
在过去 30 1 个，Kult 绝对没有售出一个 NFT。

![nft](unnamed.png)