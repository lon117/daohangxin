---
title: "Dooliens"
description: "Dooliens 是一个 NFT（不可替代代币）集合。存储在区块链上的数字艺术品集合。"
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dooliens.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/dooliens"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/dooliens/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**杜林斯统计**

创建于 6 个月前，2,870 代币供应，5% 费用

过去 7 天内没有出售 Dooliens。

一个社区驱动的外星人收藏品项目，灵感来自涂鸦。Dooliens 有一系列令人愉悦的颜色和特征，收藏规模为 +5,000。

Dooliens NFT - 常见问题（FAQ）
▶ 什么是Dooliens？
Dooliens 是一个 NFT（不可替代代币）集合。存储在区块链上的数字艺术品集合。
▶ 有多少 Dooliens 代币？
总共有 2,870 个 Dooliens NFT。目前有 15 位所有者的钱包中至少有一个 Dooliens NTF。
▶ 最近卖了多少杜林？
过去 30 天内售出 0 个 Dooliens NFT。

![nft](unnamed.png)