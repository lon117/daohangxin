---
title: "DooGods"
description: ""
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doogods.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://doogods.xyz/"
twitter: "https://www.twitter.com/DooGodsNFT"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**斗神统计**

创建于 3 个月前，5,555 代币供应，6.9% 费用

DooGods NFT 在过去 7 天内售出 1 次。DooGods 的总销售额为 0.22 美元。一个 DooGods NFT 的平均价格为 0.2 美元。DooGods 拥有者 1,876 人，总供应量为 5,555 个。

DeGods 祝福的涂鸦。5555 DooGods 在以太坊中拯救你的灵魂！即时展示，免费薄荷糖，神级艺术！售罄！

DooGods NFT - 常见问题（FAQ）
▶ 什么是 DooGods？
DooGods 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。
▶ DooGods 代币有多少？
总共有 5,555 个 DooGods NFT。目前，1,876 位所有者的钱包中至少有一个 DooGods NTF。
▶ 最昂贵的 DooGods 销售是什么？
最昂贵的 DooGods NFT 是 DooGods #3226。它于 2022 年 6 月 12 日（2 个月前）以 7.3 美元的价格售出。
▶ 最近卖了多少斗神？
过去 30 天内共售出 8 个 DooGods NFT。
▶ 什么是流行的 DooGods 替代品？
许多拥有 DooGods NFT 的用户还拥有 Fantastic Alien ETH、 APE BANKING CLUB-NFT ABC METABANK、 Loser Ape Club Official和 Sins of Shadow。

![nft](unnamed.png)