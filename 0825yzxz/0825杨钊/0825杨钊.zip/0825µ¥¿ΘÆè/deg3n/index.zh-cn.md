---
title: "deg3n"
description: "deg3n 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。"
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "deg3n.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://www.deg3n.xyz/"
twitter: "https://www.twitter.com/deg3n3"
discord: "https://discord.gg/MB5DntX2bq"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**deg3n 统计**

创建于 3 个月前，632代币供应，7.5% 费用

过去 7 天没有销售 deg3n。

第 1 阶段 - 777 分钟。前111免费。
阶段2- ？？？
第三阶段- ???

deg3n NFT - 常见问题（FAQ）
▶ 什么是 deg3n？
deg3n 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。
▶ 有多少个 deg3n 代币？
总共有 632 个 deg3n NFT。目前 522 位所有者的钱包中至少有一个 deg3n NTF。
▶ 最昂贵的 deg3n 销售是什么？
销售的最昂贵的 deg3n NFT 是 deg3n Phase 1。它于 2022-06-11（2 个月前）以 15.7 美元的价格售出。
▶ 最近卖出了多少个deg3n？
过去 30 天内售出了 5 个 deg3n NFT。

![nft](unnamed.png)