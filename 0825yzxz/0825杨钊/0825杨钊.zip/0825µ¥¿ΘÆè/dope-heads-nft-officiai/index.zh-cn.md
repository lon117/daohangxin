---
title: "Dope Heads NFT OfficiaI"
description: "DopeHeads 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。"
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dope-heads-nft-officiai.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://dopeheads.com/"
twitter: "https://www.twitter.com/dopeheadsnft"
discord: "https://discord.gg/dopeheadsnft"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/dopeheadsnft/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**DopeHeads 统计数据**

创建于 5 个月前，893代币供应，10% 费用

过去 7 天没有售出任何 DopeHeads。

MetaVerse 中的 Dopest NFT - 这是官方的 Dopeheads NFT Opensea 页面。我们有很多盗版者，如有任何问题，请随时在 Instagram 上联系 Towdown @dopeheadsnft 或在 Instagram 上联系 Mike Frost @slfemp。官方铸币在 Dopeheads.com 上，项目信息在 Dopeheadsnft.com 上 - 加入我们的不和谐以获取更多信息 - 所有 DMS 都是骗局

DopeHeads NFT - 常见问题（FAQ）
▶ 什么是 DopeHead？
DopeHeads 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。
▶ 存在多少 DopeHeads 代币？
总共有 893 个 DopeHeads NFT。目前，324 位所有者的钱包中至少有一个 DopeHeads NTF。
▶ 最昂贵的 DopeHeads 销售是什么？
最昂贵的 DopeHeads NFT 是 DOPEHEADS NFT Series 1。它于 2022 年 6 月 25 日（2 个月前）以 121.9 美元的价格售出。
▶ 最近售出了多少 DopeHead？
过去 30 天内售出了 13 个 DopeHeads NFT。
▶ DopeHeads 的价格是多少？
在过去 30 天里，DopeHeads NFT 最便宜的销售额低于 66 美元，最高销售额超过 122 美元。过去 30 天内，DopeHeads NFT 的中位价格为 90 美元。
▶ 什么是流行的 DopeHeads 替代品？
许多拥有 DopeHeads NFT 的用户还拥有 Mutant Tiny Dinos (eth)、 AJC - The Album、 PuffyPals和 goblinbucks。

![nft](unnamed.png)