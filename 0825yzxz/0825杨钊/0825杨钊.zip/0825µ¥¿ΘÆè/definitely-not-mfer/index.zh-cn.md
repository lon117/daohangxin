---
title: "Definitely Not Mfer"
description: "受到社区创建的项目 mfers 的启发。50% 的版税用于 mfers 社区钱包"
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "definitely-not-mfer.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/definitely-not-mfer"
twitter: "https://www.twitter.com/DNmfers"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**绝对不是 Mfer 统计数据**

创建于 6 个月前，5,555 代币供应，10% 费用

过去 7 天内没有绝对不是 Mfer 出售。

受到社区创建的项目 mfers 的启发。

50% 的版税用于 mfers 社区钱包

绝对不是 Mfer NFT - 常见问题 (FAQ)

▶ 什么是绝对非 Mfer？

绝对不是 Mfer 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。

▶ 有多少肯定不是 Mfer 代币？

总共有 5,555 个绝对不是 Mfer NFT。目前，288 位车主的钱包中至少有一个绝对不是 Mfer NTF。

▶ 最近卖出了多少份“绝对不是 Mfer”？

过去 30 天内售出 0 个绝对不是 Mfer NFT。

![nft](unnamed.png)