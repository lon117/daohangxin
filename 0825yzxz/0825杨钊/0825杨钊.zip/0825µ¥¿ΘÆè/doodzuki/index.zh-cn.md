---
title: "Doodzuki"
description: "Doodzuki 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。"
date: 2022-08-25T00:00:00+08:00
lastmod: 2022-08-25T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doodzuki.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.doodzuki.com/"
twitter: ""
discord: "https://discord.gg/XjcQxTks"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
**豆豆统计**

创建于 7 个月前，5,000 代币供应，2.5% 费用

过去 7 天没有出售 Doodzuki。

豆豆 | 生活在以太坊区块链上的 5000 个 Doodzuki NFT 的独特集合 | 向最优秀的人致敬

Doodzuki NFT - 常见问题（FAQ）
▶ 什么是Doodzuki？
Doodzuki 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。
▶ Doodzuki 代币有多少？
总共有 5,000 个 Doodzuki NFT。目前 569 位车主的钱包中至少有一个 Doodzuki NTF。
▶ 最近卖了多少 Doodzuki？
过去 30 天内共售出 0 个 Doodzuki NFT。

![nft](unnamed.jpg)