---
title: "AAA Pass"
description: "您的 AAA 通行证是在 Vandal Corp 社区内获得奖励和白名单的黄金门票。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elliotkiddanger-aaa-pass.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://mint.elliotkiddanger.com/"
twitter: "https://www.twitter.com/ElliotKidDanger"
discord: "https://discord.gg/gv87fc32yJ"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/elliotkiddanger"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
您的 AAA 通行证是在 Vandal Corp 社区内获得奖励和白名单的黄金门票。

今年我们将放弃 4 个 Music NFT 合集，为社区成员提供惊人的奖励。在过去的 2 周内，我们的通行证持有者赠送了 6 块 Apple 手表和超过 500 美元，还有更多！

拿起你的通行证，加入破坏者。*AAA 通行证*已经举办了十多年的售罄活动，是布莱顿学生的终极新生通行证。使命。致力于使艺术家能够建立自己的平台，讲述自己的故事并提供访问所有区域的*权限*...

![NFT](1.jpg)