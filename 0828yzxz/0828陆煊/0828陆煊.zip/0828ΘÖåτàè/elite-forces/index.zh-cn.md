---
title: "Elite Forces"
description: "精英部队是一个由精心手绘和各方面细节制作的专属士兵的创世纪系列"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elite-forces.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/elite-forces"
twitter: "https://www.twitter.com/EliteForcesNFT"
discord: "https://discord.gg/eliteforces"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
精英部队是一个由精心手绘和各方面细节制作的专属士兵的创世纪系列。受到世界各地退伍军人的启发，200 件收藏品的创作理念是优先考虑作品的质量。当前Genesis系列的持有者将从我们的下一个系列中空投一个免费的NFT！《*精英部队*》力求带给玩家带来最丰富的射击游戏体验。《*精英部队*》采用了3D写实风格的画面，现场录制的真实精英部队是一个由精心手绘和各方面细节制作的专属士兵的创世纪系列。受到世界各地退伍军人的启发，200 件收藏品的创作理念是优先考虑作品的质量。当前Genesis系列的持有者将从我们的下一个系列中空投一个免费的NFT！

![NFT](1.png)