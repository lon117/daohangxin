---
title: "ELTI EDITIONS"
description: "这是由 Manifold 提供支持的“ELTI EDITIONS”官方合集。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elte.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/elte"
twitter: "https://www.twitter.com/Elti_Art"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/elti_art"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
这是由 Manifold 提供支持的“ELTI EDITIONS”官方合集。非获奖视觉艺术家!有时是优秀收藏家

我有大量未铸造的艺术品，华丽的作品，只是在等待合适的收藏家舀出我最后几件可用的艺术品。每一次 RT 都让我更接近将我的艺术带给真正欣赏和珍惜它们的人！艾尔蒂的*阿斯特利亚*。在星星中，繁星之一。为神秘存在带来光明的流星女神。--- 这幅画将是......*Elti*总部位于阿尔巴尼亚，有机地扩大了其全球追随者和影响力……第 1*版……* *Elti*的 Blooming 市场统计

![NFT](1.png)