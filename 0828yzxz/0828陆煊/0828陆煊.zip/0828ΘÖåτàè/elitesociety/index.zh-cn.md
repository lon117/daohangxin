---
title: "The Elite Society"
description: "拥有1337名精英的专属社团。你够精英吗？"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elitesociety.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/elitesociety"
twitter: "https://www.twitter.com/elitesocietynft"
discord: "https://discord.gg/elite-society"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
属于高科技社会的精英手绘个体。每个内部都将被提炼，以最大限度地提高其优雅性。1/XXXX通用精英！祝大家星期天快乐。今天我将从第二次抽奖中选择另一位获胜者，因为其中一位获胜者没有按时返回。请务必查看您的 DM，我会在一分钟内处理!。今天没有抽奖，来点草吧爱，大师等待第二个中奖者申请私人销售，如果没有要求，我将转移到下一个中奖者！确保打开 DM 并关注

![NFT](1.png)