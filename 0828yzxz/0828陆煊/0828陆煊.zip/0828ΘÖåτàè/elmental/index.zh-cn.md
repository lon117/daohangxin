---
title: "ElementaI"
description: "Elemental 系列旨在展示这些小事如何彻底改变艺术家的生活。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elmental.jpg"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.loopfx.org/"
twitter: "https://www.twitter.com/LxxpFx"
discord: "https://discord.gg/pjhtjD8r"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
与 Emancipation 系列不同，我想展示我们艺术家在创作过程中如何挣扎，以及小事会对我们产生怎样的负面影响，Elemental 系列旨在展示这些小事如何彻底改变艺术家的生活。生活中没有什么会轻松一点，不要误会自己没有努力的梦想生活，没有工作和汗水什么都不会发生，很可能会被那些想欺骗你的人视为理所当然，记住，你永远有力量决定你想要什么！！您现在可以购买我的艺术版画了！这不是很神奇吗？让它们尽可能便宜，这样每个人都可以自己买一个！

![NFT](1.png)