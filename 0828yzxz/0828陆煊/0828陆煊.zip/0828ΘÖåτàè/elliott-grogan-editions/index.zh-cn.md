---
title: "Elliott Grogan Editions"
description: "这个系列的特色是让我想把摄影作为一门艺术来追求的照片版本。每张图片均于 2016 年在洛杉矶市中心创建。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elliott-grogan-editions.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/elliott-grogan-editions"
twitter: "https://www.twitter.com/Elliott_Grogan"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
这个系列的特色是让我想把摄影作为一门艺术来追求的照片版本。每张图片均于 2016 年在洛杉矶市中心创建。金色和蓝色的海湾大桥是城市景观有限的 NFT 收藏，其中包含 2022 年拍摄的旧金山海湾大桥的单张照片。我在家人的重要时刻拍摄了这些照片，每张照片都提醒人们要相信这条路即使道路模糊不清，你也知道新的早晨总会带来新的可能性。该系列是在 Solana 区块链上铸造的，可在 Exchange Art 获得。th x Broadway 是一张城市风景照片，可作为 NFT 版本 15。我于 2016 年在洛杉矶市中心拍摄了这张照片，它是让我想将摄影作为一门艺术追求的第一批作品之一。这张照片很特别，因为它将观众放在我的鞋子里，让他们体验 2016 年洛杉矶市中心的感觉。这些版本是在以太坊区块链上铸造的，并于 2022 年 6 月 28 日售罄。这些版本可能会通过 OpenSea 在二级市场上发售。

![NFT](1.png)