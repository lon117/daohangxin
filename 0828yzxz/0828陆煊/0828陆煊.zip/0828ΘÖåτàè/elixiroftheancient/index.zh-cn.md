---
title: "Elixir of The Ancient"
description: "上古灵药开始了链面宇宙的下一章。长生不老药可用于将您的 CFA 升级为 Chainfaces HD 角色的新形式。或者，如果您陷入原始竞技场的续集，它可以用来恢复您的链面。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "elixiroftheancient.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://chainfaceshd.com/"
twitter: "https://www.twitter.com/secretproject"
discord: "https://discord.gg/secretproject"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
上古灵药开始了链面宇宙的下一章。长生不老药可用于将您的 CFA 升级为 Chainfaces HD 角色的新形式。或者，如果您陷入原始竞技场的续集，它可以用来恢复您的链面。该物品可以在找到配方：*上古灵药*后制作。它也可以从 Boss 和英雄生物中随机掉落它是从烈焰的阿奇瑞乌斯那里获得的。在其他消耗品类别中。魔兽世界：熊猫人之谜中的一件物品。始终保持最新。

CF HD 和 Arena 续集都将在不久的将来活跃。

![NFT](1.png)