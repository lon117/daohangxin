---
title: "EL PARTY"
description: "加入 EL PARTY出价认领此音乐 NFT。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "el-party.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://xcelencia.io/"
twitter: "https://www.twitter.com/Xcelencia"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/xcelencia"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
加入 EL PARTY出价认领此音乐 NFT。参加派对的人：
\- 可以在 Rally 上领取 $EQUIS。
\- 加入我的封闭式不和谐和未发行音乐库。
\- 访问以在发布前查看音乐视频。观影派对？
\- 在发布之前访问 BTS 的音乐视频。
\- 未来的白名单。

艺术。由 AVIV（墨西哥）生产。作者：JVY 男孩（智利）特别感谢“XCELENCIA 的无限”支持者：$EQUIS 是在 Rally 上推出的一种社交代币，它为我的数字粉丝俱乐部提供动力。支持者为超级粉丝解锁了对带有角色的封闭式 Discord 服务器和 WhatsApp 群组的访问权限，我在其中分享独家内容、赠品和数字收藏品。

![NFT](1.png)