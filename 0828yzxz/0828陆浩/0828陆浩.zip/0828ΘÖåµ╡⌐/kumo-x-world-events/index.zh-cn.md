---
title: "Kumo X World Events"
description: "Kumo X World 活动"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "kumo-x-world-events.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://kumoxworld.com/"
twitter: "https://www.twitter.com/kumoxworld"
discord: "https://discord.gg/kumoxworld"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/kumoxworld"
reddit: ""
medium: "https://www.medium.com/@kumoxworld"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
NFT stats 为您提供有关 NFT 空间的最新信息。如果您想找到最好的 NFT 购买、即将推出的 NFT 项目、最昂贵的 NFT 是什么——我们将为您提供您需要的数据、图表、见解和新闻。
本网站上的数据来自各种 NFT 市场和 NFT 项目创建者自己。我们还直接从 Twitter 和 Discord 获取 NFT 社区统计数据。过去 7 天没有售出 Kumo X World 活动。▶什么是Kumo X World Events？
Kumo X World Events 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。
▶ 有多少 Kumo X World Events 代币？
总共有 2 个 Kumo X World Events NFT。目前，5,302 位车主的钱包中至少有一个 Kumo X World Events NTF。
▶ 最近售出了多少 Kumo X World 活动？
过去 30 天内售出 0 个 Kumo X World Events NFT。

![nft](1661680420039.png)