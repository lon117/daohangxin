---
title: "Lady Apes Of Space Official"
description: "专为 AoS NFT 所有者分发。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "ladyapesofspace-official.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://apesofspace.com/"
twitter: "https://www.twitter.com/ApesofSpace_nft"
discord: "https://discord.gg/rRrnHCQsvn"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/apesofspace_nft"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
专为 AoS NFT 所有者分发。  Apes Of Space 持有者将能够从 12 月 17 日起免费获得薄荷 Lady Apes Of Space。 猿猴与猿猴的比例为1:1，如果您拥有5只原始猿，则可以免费铸造5只猿猴。 （只需支付汽油）。 不会公开发售，这些仅限于 Apes Of Space 持有者。醒醒，Neo……矩阵有你……关注 Apes Of Space！▶ 什么是太空人猿女官？
Lady Apes Of Space Official 是一个 NFT（非同质代币）系列。 存储在区块链上的数字艺术品集合。
▶ Lady Apes Of Space 官方代币有多少？
总共有 3,000 个 Lady Apes Of Space 官方 NFT。 目前，1,740 位车主的钱包中至少有一本 Lady Apes Of Space Official NTF。

![nft](1661687675927.jpg)