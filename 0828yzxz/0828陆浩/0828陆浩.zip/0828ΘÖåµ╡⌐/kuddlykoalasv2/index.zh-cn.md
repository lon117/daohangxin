---
title: "KuddlyKoalasV2"
description: "提醒是实时的！"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "kuddlykoalasv2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/kuddlykoalasv2"
twitter: "https://www.twitter.com/KuddlyKoalasNFT"
discord: "https://discord.gg/zBgHStCPfc"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
##### ▶ 什么是 KuddlyKoalasV2？

KuddlyKoalasV2 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 KuddlyKoalasV2 代币？

总共有 1,829 个 KuddlyKoalasV2 NFT。目前，569 位所有者的钱包中至少有一个 KuddlyKoalasV2 NTF。

##### ▶ 最近卖出了多少 KuddlyKoalasV2？

过去 30 天内售出了 1 个 KuddlyKoalasV2 NFT。NFT stats 为您提供有关 NFT 空间的最新信息。如果您想找到最好的 NFT 购买、即将推出的 NFT 项目、最昂贵的 NFT 是什么——我们将为您提供您需要的数据、图表、见解和新闻。
本网站上的数据来自各种 NFT 市场和 NFT 项目创建者自己。我们还直接从 Twitter 和 Discord 获取 NFT 社区统计数据

![nft](1661659961668.jpg)