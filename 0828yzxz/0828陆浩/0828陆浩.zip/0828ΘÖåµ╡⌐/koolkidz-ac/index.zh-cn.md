---
title: "Kool Kidz by Arcade Studio"
description: "我们是酷孩子。 辍学者，失败者，书呆子，不合群的人 免费薄荷是活的"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "koolkidz-ac.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://koolkidzarcade.io/"
twitter: "https://www.twitter.com/KoolKidzArcade"
discord: "https://discord.gg/HKqJGG6t"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
我们是酷孩子。 辍学者，失败者，书呆子，不合群的人 免费薄荷是活的

▶ Arcade Studio 的 Kool Kidz 是什么？
Arcade Studio 的 Kool Kidz 是一个 NFT（不可替代代币）系列。存储在区块链上的数字艺术品集合。
▶ Arcade Studio 代币有多少 Kool Kidz？
Arcade Studio NFT 总共有 5,000 个 Kool Kidz。目前，724 位所有者的钱包中至少有一个 Kool Kidz by Arcade Studio NTF。
▶ Arcade Studio 最贵的 Kool Kidz 销售是什么？
Arcade Studio NFT 出售的最昂贵的 Kool Kidz 是 KoolKidz_#3512。它于 2022-06-18（2 个月前）以 329.3 美元的价格售出。
▶ Arcade Studio 最近卖出了多少 Kool Kidz？
在过去 30 天内，Arcade Studio NFT 共售出 663 个 Kool Kidz。
▶ Arcade Studio 的 Kool Kidz 需要多少钱？
过去 30 天，最便宜的 Kool Kidz by Arcade Studio NFT 销售额低于 4 美元，最高销售额超过 16 美元。过去 30 天，Arcade Studio NFT 的 Kool Kidz 的中位数价格为 8 美元。
▶ Arcade Studio 流行的 Kool Kidz 替代品有哪些？
许多拥有 Arcade Studio NFT 的 Kool Kidz 的用户还拥有 Ape Invaders Genesis、 Cult of Cheetah、 The Entroverts和 Potatoez的 Kiss My Ass。
 交互式 NFT 项目：Goofball Gang。立即购买。

![nft](1661657015789(1).png)