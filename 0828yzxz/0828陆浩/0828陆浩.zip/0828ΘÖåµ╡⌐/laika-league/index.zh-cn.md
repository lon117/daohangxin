---
title: "Laika League"
description: "Laika League 是一个对初学者友好的原创 NFT 项目，旨在帮助新手"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "laika-league.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.laikaleague.com/"
twitter: "https://www.twitter.com/LaikaLeague"
discord: "https://discord.gg/rQEvSQjQ6M"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/laikaleague"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是莱卡联赛？
Laika League 是一个 NFT（Non-fungible token）集合。 存储在区块链上的数字艺术品集合。
▶ 莱卡联盟代币有多少？
总共有 905 个莱卡联盟 NFT。 目前，132 位车主的钱包中至少有一份莱卡联赛 NTF。
▶ 最近卖了多少莱卡联赛？
过去 30 天内共售出 0 个 Laika League NFT。Laika League 是一个对初学者友好的原创 NFT 项目，旨在帮助新手。 莱卡人本身就是帮助我们完成这项任务的可爱向导。 我们的系列包括 10,000 名莱卡人，他们有各种不同的服装、眼睛、发型、帽子等等。 每一个都是独一无二的； 没有两个莱卡看起来像！

![nft](1661688095801.jpg)