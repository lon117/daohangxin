---
title: "LAIKA NFT TICKET"
description: "徕卡 NFT 3 月 23 日狗日庆典 NFT 项目"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "laika-nft-ticket.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.laika-nft.com/"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/laika_nft"
reddit: ""
medium: "https://www.medium.com/@laika_NFT"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Leica NFT 3 月 23 日纪念狗日的 NFT 项目 Leica NFT 向持有者发行定制宠物 PFP，并将收益捐赠给动物福利组织。 为纪念3月23日的狗日，和我们一起实践对动物的爱！为纪念3月23日的狗日，和我们一起实践对动物的爱！ 徕卡 NFT 项目门票持有者将于 4 月 1 日在徕卡主页上参与创建反映其宠物特征的定制 PFP。详情请查看官网！铸币很贴心！ 生成具有各种属性的宠物的自定义 PFP。 利润将捐赠给动物非政府组织。

![nft](1661688234255.jpg)