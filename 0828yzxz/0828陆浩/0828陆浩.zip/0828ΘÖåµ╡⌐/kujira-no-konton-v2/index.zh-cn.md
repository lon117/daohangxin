---
title: "KUJIRA NO KONTON - Gen 1"
description: "在 2024 年减半之后，鲸鱼控制并统治了一个血流成河的独裁统治"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "kujira-no-konton-v2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://kujiranokonton.com/"
twitter: "https://www.twitter.com/KujiraNoKonton"
discord: "https://discord.gg/kujiranokonton"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
在 2024 年减半之后，鲸鱼控制并统治了一个血流成河、分裂达到顶峰的独裁政权。 在这个混乱的世界里，人类和鲸鱼不是生活在一起的，而是彼此撕裂的。 这个 Manga-NFT 在其写作和章程上都具有创新性，由于其治理和公众，该项目希望同时成为社区，其目标是超越加密货币世界的公众。▶ 什么是 KUJIRA NO KONTON - Gen 1？
KUJIRA NO KONTON - Gen 1 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。
▶ KUJIRA NO KONTON - Gen 1 代币有多少？
总共有 720 个 KUJIRA NO KONTON - Gen 1 NFT。目前，412 位车主的钱包中至少有一个 KUJIRA NO KONTON - Gen 1 NTF。

![nft](1661660163571.jpg)