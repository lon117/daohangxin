---
title: "Kurayami Kara Genesis"
description: "从我们聚集的阴影中 | 我们从阴影中升起"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "kurayami-kara-genesis.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/kurayami-kara-genesis"
twitter: "https://www.twitter.com/KURAYAMIKARANFT"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
从我们聚集的阴影中 | 从我们升起的阴影中，Kurayami Kara Genesis 是您通往 4,000 个独特叛乱 NFT 的门户。持有者将获得空投、突变和尚未展开的 Kuryami Kara 故事情节的血统。起义即将来临。角色召唤很明确：Will 你宣誓效忠并加入我们的战斗？▶ 什么是Kurayami Kara Genesis？
Kuryami Kara Genesis 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。
▶ 有多少个Kurayami Kara Genesis 代币？
总共有 71 个 Kuryami Kara Genesis NFT。目前有 25 位车主的钱包中至少有一个 Kuryami Kara Genesis NTF。
▶ 最近卖出了多少个Kurayami Kara Genesis？
过去 30 天内共售出 0 个 Kuryami Kara Genesis NFT。

![nft](1661680957448.jpg)