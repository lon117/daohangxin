---
title: "Koshiro Genesis"
description: "Koshiro Genesis 是下一代艺术家集体的 2,000 个化身的集合，"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "koshiro-genesis.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/koshiro-genesis"
twitter: "https://www.twitter.com/KoshiroNFT"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Koshiro Genesis 是一个包含 2,000 个化身的集合，适用于下一代艺术家、建造者和规则破坏者。 在元宇宙中精心设计并出生于日本，持有者可以获得独家的 Koshiro Genesis 产品，并有机会塑造我们共同的未来。 加入我们追逐海啸的行列。▶ 什么是 Koshiro Genesis？
Koshiro Genesis 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。
▶ 有多少 Koshiro Genesis 代币？
总共有 2,025 个 Koshiro Genesis NFT。目前，357 位车主的钱包中至少有一个 Koshiro Genesis NTF。
▶ 最近卖了多少Koshiro Genesis？
过去 30 天内售出 0 个 Koshiro Genesis NFT。

![nft](1661658496879.jpg)