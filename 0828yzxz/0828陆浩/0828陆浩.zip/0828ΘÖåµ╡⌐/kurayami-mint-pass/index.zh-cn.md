---
title: "Kurayami Mint Pass"
description: "Genesis Mint Pass 3 免费薄荷糖进入 The Hidden Early access"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "kurayami-mint-pass.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.projectkurayami.com/"
twitter: "https://www.twitter.com/ProjectKurayami"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Genesis Mint Pass 3 免费薄荷糖进入 The Hidden Early access▶ 什么是仓水薄荷通行证？
Kuryami Mint Pass 是一个 NFT（非同质代币）系列。存储在区块链上的数字艺术品集合。
▶ 有多少仓水铸币厂通行证？
总共有 1 个 Kuryami Mint Pass NFT。目前 3 位所有者的钱包中至少有一张仓见薄荷通行证 NTF。
▶ 最近卖出了多少仓水薄荷通行证？
过去 30 天内共售出 0 个 Kuryami Mint Pass NFT。
▶ 有哪些流行的仓见薄荷通行证替代品？
许多拥有仓见薄荷通行证 NFT 的用户还拥有 Kurachan、 Satomi 的 Creature Land、 Project SOS-Genesis Pirates

![nft](1661681070707.jpg)