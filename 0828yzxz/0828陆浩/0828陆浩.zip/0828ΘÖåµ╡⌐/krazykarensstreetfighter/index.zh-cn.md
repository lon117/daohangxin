---
title: "Krazy Karens Street Fighter"
description: "赢得真正的奖品，并被加冕为终极凯伦！"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "krazykarensstreetfighter.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/krazykarensstreetfighter"
twitter: "https://www.twitter.com/KKStreetFighter"
discord: "https://discord.gg/xT9vsVjgJX"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/http://krazykarensnft.io/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是疯狂卡伦斯街头霸王？
Krazy Karens Street Fighter 是一个 NFT（非同质代币）系列。存储在区块链上的数字艺术品集合。
▶ 有多少疯狂卡伦斯街头霸王代币？
总共有 165 个 Krazy Karens Street Fighter NFT。目前有 102 位车主的钱包里至少有一个 Krazy Karens Street Fighter NTF。
▶ 最近卖了多少疯狂卡伦斯街头霸王？
过去 30 天内共售出 0 个 Krazy Karens Street Fighter NFT。

限量发行 999 个完全独特的 Krazy Karen NFT，您可以使用它们在最好的下一代区块链 NFT 游戏中与其他 Krazy Karen 战斗。 赢得真正的奖品，并被加冕为终极凯伦！

![nft](1661659138810.jpg)