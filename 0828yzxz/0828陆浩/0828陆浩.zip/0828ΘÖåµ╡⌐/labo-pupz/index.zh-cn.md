---
title: "Labo Pupz"
description: "有时候，拉波很孤独。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "labo-pupz.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/labo-pupz"
twitter: "https://www.twitter.com/labo_nft"
discord: "https://discord.gg/UsBexNXWTA"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
1 Labo for 1 Pupz (Airdrop) 持有人快照时间 02/13/2022，声称 pupz 继续 https://pupz.labonft.xyz/有时 Labo 很孤独。 这就是为什么每个 Labo 都必须有一个四足同伴。 为了好玩或与混蛋 Luciv 战斗。 这就是我们创建 Labo Pupz 的原因，以及我们提供 NFT pupz 供每个 Labo Fam 采用的原因。▶ 什么是 Labo Pupz？
Labo Pupz 是一个 NFT（非同质代币）集合。 存储在区块链上的数字艺术品集合。
▶ Labo Pupz 代币有多少？
总共有 2,398 个 Labo Pupz NFT。 目前，535 位车主的钱包中至少有一个 Labo Pupz NTF。
▶ 最近卖出了多少 Labo Pupz？
过去 30 天内售出 0 个 Labo Pupz NFT。

![nft](1661687344463.jpg)