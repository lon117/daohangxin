---
title: "Krubber Duckiez"
description: "将我们的现实与 KRUBBERVERSE 连接起来的门户已经打开！"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "krubber-duckiez-2.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.krubberverse.com/"
twitter: "https://www.twitter.com/KrubberVerse"
discord: "https://discord.gg/jE58BCEmC6"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Krubber Duckiez OG 300 是一个 NFT（非同质代币）系列。存储在区块链上的数字艺术品集合。
▶ 有多少 Krubber Duckiez OG 300 代币？
总共有 300 个 Krubber Duckiez OG 300 NFT。目前，146 位车主的钱包中至少有一只 Krubber Duckiez OG 300 NTF。
▶ 最近售出了多少 Krubber Duckiez OG 300？
在过去 30 天内售出了 0 个 Krubber Duckiez OG 300 NFT。将我们的现实与 KRUBBERVERSE 连接起来的门户已经打开！传送门有……鸭子那么大！300 只 Krubber Duckiez 从传送门中掉了下来，并被密封在自动售货机的胶囊中。收集它们、分享它们、交易它们并准备好帮助将它们归还给 The KrubberVerse。

![nft](1661659406861.jpg)