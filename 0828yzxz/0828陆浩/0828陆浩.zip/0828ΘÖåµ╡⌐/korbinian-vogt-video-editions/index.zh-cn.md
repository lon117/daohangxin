---
title: "Korbinian Vogt - Video Editions"
description: "Korbinian Vogt 的视频版本。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "korbinian-vogt-video-editions.jpg"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://www.korbinianvogt.com/"
twitter: "https://www.twitter.com/korbinian_vogt"
discord: "https://discord.gg/invite/kxh8pyBD5G"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/korbinianvogt"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是 Korbinian Vogt - 版本？
Korbinian Vogt - Editions 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。
▶ 存在多少 Korbinian Vogt - Editions 代币？
总共有 250 个 Korbinian Vogt - Editions NFT。目前，153 位所有者的钱包中至少有一个 Korbinian Vogt - Editions NTF。
▶ 什么是最昂贵的 Korbinian Vogt - Editions 销售？
出售的最昂贵的 Korbinian Vogt-Editions NFT 是 At Besseggen 25/25。它于 2022-06-04（3 个月前）以 91 美元的价格售出。
▶ 最近售出了多少 Korbinian Vogt - 版本？
过去 30 天内售出了 27 个 Korbinian Vogt - Editions NFT。
▶ Korbinian Vogt - Editions 的价格是多少？
在过去 30 天里，最便宜的 Korbinian Vogt - Editions NFT 销售额低于 0 美元，最高销售额超过 33 美元。在过去 30 天内，Korbinian Vogt - Editions NFT 的中位价格为 0 美元。
▶ 什么是流行的 Korbinian Vogt - Editions 替代品？
许多拥有 Korbinian Vogt-Editions NFT 的用户还拥有 yeethz editionz、 Geodetic Moments、 Monsters of Mind和 Host Memorial。

![nft](1661657557816.jpg)