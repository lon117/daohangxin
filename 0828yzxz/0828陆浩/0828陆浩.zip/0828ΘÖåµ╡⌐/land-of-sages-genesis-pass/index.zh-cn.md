---
title: "Land of Sages Genesis Pass"
description: "圣域创世关"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "land-of-sages-genesis-pass.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/land-of-sages-genesis-pass"
twitter: "https://www.twitter.com/LandOfSages"
discord: "https://discord.gg/lanofsages"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/landofsages"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是圣域创世关？
贤者之地创世通行证是一个 NFT（非同质代币）集合。 存储在区块链上的数字艺术品集合。
▶ 先贤之地创世通行证有多少？
总共有 1 个贤者之地创世通行证 NFT。 目前，62 位所有者的钱包中至少有一张 Land of Sages Genesis Pass NTF。
▶ 最近卖出了多少圣域创世通行证？
过去 30 天内共售出 0 个贤者之地创世通证 NFT。存储在区块链上的数字艺术品集合。
贤者之地创世纪通行证社区统计

![nft](1661689312707.jpg)