---
title: "KOXEL"
description: "韩国 NFT 艺术家的可穿戴设备商店"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "korean-nft-1.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://koreannft.com/"
twitter: "https://www.twitter.com/koreannft"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/koreannfthttps://www.instagram.com/koreannfthttps://www.instagram.com/koreannfthttps://www.instagram.com/koreannfthttps://www.instagram.com/koreannft"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
##### ▶ 什么是 KOXEL？

KOXEL 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少个 KOXEL 代币？

总共有 226 个 KOXEL NFT。目前，2,260 位车主的钱包中至少有一个 KOXEL NTF。

##### ▶ 最近卖出了多少KOXEL？

过去 30 天内售出 0 个 KOXEL NFT。

NFT stats 为您提供有关 NFT 空间的最新信息。如果您想找到最好的 NFT 购买、即将推出的 NFT 项目、最昂贵的 NFT 是什么——我们将为您提供您需要的数据、图表、见解和新闻。
本网站上的数据来自各种 NFT 市场和 NFT 项目创建者自己。我们还直接从 Twitter 和 Discord 获取 NFT 社区统计数据。

![nft](1661658024837.jpg)