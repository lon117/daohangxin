---
title: "Lamerz"
description: "1000 CC0 Lamerz 生活在 paulmandl.eth 和 drknss.eth 的区块链上"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lamerz.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://launchmynft.io/collections/"
twitter: "https://www.twitter.com/drknssBYsascha"
discord: "https://discord.gg/CJm7Unrvgr"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是 Lamerz？
Lamerz 是一个 NFT（不可替代代币）集合。 存储在区块链上的数字艺术品集合。
▶ 存在多少个 Lamerz 代币？
总共有 1,000 个 Lamerz NFT。 目前，450 位车主的钱包中至少有一个 Lamerz NTF。
▶ 最近卖出了多少 Lamerz？
过去 30 天内售出 0 个 Lamerz NFT。
▶ 什么是流行的 Lamerz 替代品？
许多拥有 Lamerz NFT 的用户还拥有 666 DEGEN PIGZ、AIKaijuz、DuckDuckWorld 和 I'm Nothing。1000 CC0 Lamerz 生活在 paulmandl.eth 和 drknss.eth 的区块链上

![nft](1661688451210(1).jpg)