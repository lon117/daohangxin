---
title: "Lab GoblinZ"
description: "10000 LabGoblinZ 是已故 Labcoats 的阴暗意图，表现为一个物理存在，并在实验室中肆虐。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "labgoblinz.jpg"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "http://serumlabznft.xyz/"
twitter: "https://www.twitter.com/SerumLabzNFT"
discord: "https://discord.gg/SerumLabz"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
警告！ 警告！ 警告！ 10000 LabGoblinZ 是已故 Labcoats 的阴暗意图，表现为一个物理存在，我们需要 Kongz 的力量来团结并控制这些阴暗的生物。并在实验室中肆虐。 因此，我们试图阻止他们在黑暗中制造混乱。 我们需要 Kongz 的力量来团结并控制这些阴暗的生物。 我们有一种感觉，虽然你们中的一些人可能会依恋并想要开始收集这些 LabGoblinZ，而你们中的一些人也会从交易这些邪恶生物中获利。 - 血清 27 - CloneKongz - Humanoidz - MutantKongz

![nft](1661687191368(1).jpg)