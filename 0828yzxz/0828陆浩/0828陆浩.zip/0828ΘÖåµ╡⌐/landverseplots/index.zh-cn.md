---
title: "LandVersePlots"
description: "Landverse 是一款带有 NFT 质押的 P2E 游戏，一个具有 2% DApp ETH 反射的 DAO，一个包含 Lands 和 Villagers 等 NFT 的市场。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "landverseplots.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/landverseplots"
twitter: ""
discord: ""
telegram: "https://t.me/landverseportal"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Landverse 是一款带有 NFT 质押的 P2E 游戏，一个具有 2% DApp ETH 反射的 DAO，一个包含 Lands 和 Villagers 等 NFT 的市场。▶ 什么是 LandVersePlots？
LandVersePlots 是一个 NFT（不可替代令牌）集合。 存储在区块链上的数字艺术品集合。
▶ 有多少个 LandVersePlots 代币？
总共有 18 个 LandVersePlots NFT。 目前，11 位所有者的钱包中至少有一个 LandVersePlots NTF。
▶ 最近售出了多少 LandVersePlot？
过去 30 天内售出 0 个 LandVersePlots NFT。
▶ 什么是流行的 LandVersePlots 替代品？
许多拥有 LandVersePlots NFT 的用户还拥有 Realms（冒险家）、Loot（冒险家）、SkuxxVerse Pass。

![nft](1661689769222(1).jpg)