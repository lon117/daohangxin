---
title: "Land DAO Genesis"
description: "我们是一个艺术策展平台，将知名艺术家带入 NFT 空间以获得独家 NFT 掉落。"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "land-dao-genesis.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/land-dao-genesis"
twitter: "https://www.twitter.com/land_dao"
discord: "https://discord.gg/HdjtXqVBWT"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
我们是一个艺术策展平台，将知名艺术家带入 NFT 空间以获得独家 NFT 掉落。 在此处加入我们的社区 。 燃烧碎片以重建艺术品！▶ 什么是 Land DAO Genesis？
Land DAO Genesis 是一个 NFT（非同质代币）集合。 存储在区块链上的数字艺术品集合。
▶ 有多少个 Land DAO Genesis 代币？
总共有 1,515 个 Land DAO Genesis NFT。 目前，413 位所有者的钱包中至少有一个 Land DAO Genesis NTF。
▶ 最近卖出了多少个 Land DAO Genesis？
过去 30 天内售出 0 个 Land DAO Genesis NFT。

![nft](1661688606918.jpg)