---
title: "KPK Relics"
description: "旅游门户带回了过去的片段。 看来克隆人正在恢复记忆……"
date: 2022-08-28T00:00:00+08:00
lastmod: 2022-08-28T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "kpk-relics.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://kopokoverse.com/"
twitter: "https://www.twitter.com/kopokostudio"
discord: "https://discord.gg/kopokomafia"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
▶ 什么是 KPK 遗物？
KPK Relics 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。
▶ 存在多少 KPK Relics 代币？
总共有 7 个 KPK Relics NFT。目前 310 位所有者的钱包中至少有一个 KPK Relics NTF。
▶ 最昂贵的 KPK Relics 销售是什么？
出售的最昂贵的 KPK Relics NFT 是 Grumpy Mount。它于 2022-07-02（大约 2 个月前）以 54.9 美元的价格售出。
▶ 最近卖出了多少KPK遗物？
过去 30 天内售出了 3 个 KPK Relics NFT。

旅游门户带回了过去的片段。 看来克隆人正在恢复记忆

![nft](1661658804901(1).jpg)